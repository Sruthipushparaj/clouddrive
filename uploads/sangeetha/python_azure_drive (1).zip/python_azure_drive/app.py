from flask import Flask, render_template, request, redirect, url_for, session
from azure.storage.blob import BlobServiceClient, BlobClient, ContainerClient
import os

app = Flask(__name__)
app.secret_key = "123"  # Change this to a random value

# Azure Blob Storage credentials
AZURE_STORAGE_CONNECTION_STRING = "your_storage_connection_string"
CONTAINER_PREFIX = "user_container_"

def create_container(container_name):
    blob_service_client = BlobServiceClient.from_connection_string(AZURE_STORAGE_CONNECTION_STRING)
    container_client = blob_service_client.create_container(container_name)

@app.route('/')
def home():
    if 'username' in session:
        return render_template('upload.html')
    else:
        return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        # Authentication logic here
        session['username'] = request.form['username']
        return redirect(url_for('home'))
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('login'))

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'username' not in session:
        return redirect(url_for('login'))

    # Get the uploaded file
    file = request.files['file']
    if file:
        # Create a container for the user if it doesn't exist
        container_name = CONTAINER_PREFIX + session['username']
        create_container(container_name)

        # Save the file to Azure Blob Storage
        blob_service_client = BlobServiceClient.from_connection_string(AZURE_STORAGE_CONNECTION_STRING)
        blob_client = blob_service_client.get_blob_client(container=container_name, blob=file.filename)
        blob_client.upload_blob(file)

    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)
